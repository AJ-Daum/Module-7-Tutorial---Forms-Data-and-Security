from django.db import models

# Create your models here.
class Book(models.Model):
    isbn = models.CharField(max_length=13)
    title = models.CharField(max_length=200)
    author = models.CharField(max_length=100)
    category = models.CharField(max_length=50)
    no_of_pages = models.SmallIntegerField()
    publication_date = models.DateField()

# string representation method
    def __str__(self):
    #    return self.title
        return f"{self.title} by {self.author}"






