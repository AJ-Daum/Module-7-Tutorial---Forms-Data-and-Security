from django.shortcuts import get_object_or_404, render
from django.http import HttpResponse
from .models import Book
from .forms import BookForm
from .forms import ContactForm



# Create your views here.
def anynameiwant(request):
    return HttpResponse("sometthing I want to be printed other than Django installed successfully")

# creating a view to pull books from our db 
def show_books(request):
    books = Book.objects.all()
    return render(request, 'index.html', {'books': books})

def add_book(request):
    form = BookForm()
    if request.method == 'POST':
        form = BookForm(request.POST)
        if form.is_valid():
            form.save()
            return HttpResponse("Book added successfully!")
    return render(request, 'add_book.html', {'form': BookForm})
    #if request.method == 'POST':


def edit_book(request, isbn):
    book = get_object_or_404(Book, isbn = isbn)
    form = BookForm(instance=book)
    if request.method == 'POST':
        form = BookForm(request.POST, instance=book)
        if form.is_valid():
            form.save()
            return HttpResponse("Book updated successfully!")
    return render(request, 'edit_book.html', {'form': BookForm})


def deletebook(request, isbn):
    book = get_object_or_404(Book, isbn = isbn)
    if request.method == 'POST':
        book.delete()
        return HttpResponse("Book deleted successfully!")
    return render(request, 'deletebook.html', {'book': book})


def contactus(request):
    if request.method == 'POST':
        form = ContactForm(request.POST)
        if form.is_valid():
            name = form.cleaned_data['name']
            email = form.cleaned_data['email']
            comments = form.cleaned_data['comments']
    else:
        form = ContactForm()
    return render(request, 'contact.html', {'form': form})




