from django import forms

from .models import Book


class BookForm(forms.ModelForm):
    class Meta:
        model = Book
        fields = ['isbn', 'title', 'author', 'category', 'no_of_pages', 'publication_date']


class ContactForm(forms.Form):
    name = forms.CharField(max_length=100)
    email = forms.EmailField(widget=forms.EmailInput)
    comments = forms.CharField(max_length=1000, widget=forms.Textarea)









